#pragma once

void optimizationTask(); 